# vendor_app/views.py

from rest_framework import generics,status
from rest_framework.response import Response
from django.shortcuts import render
from rest_framework import viewsets
from django.utils import timezone 
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated

from .models import Vendor, PurchaseOrder
from .serializers import VendorSerializer, PurchaseOrderSerializer,HistoricalPerformanceSerializer

class VendorListCreateView(generics.ListCreateAPIView):
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

class VendorDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer

class PurchaseOrderListCreateView(generics.ListCreateAPIView):
    queryset = PurchaseOrder.objects.all()
    serializer_class = PurchaseOrderSerializer

class PurchaseOrderDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = PurchaseOrder.objects.all()
    serializer_class = PurchaseOrderSerializer

class VendorPerformanceView(generics.RetrieveAPIView):
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        performance_data = {
            'on_time_delivery_rate': instance.on_time_delivery_rate,
            'quality_rating_avg': instance.quality_rating_avg,
            'average_response_time': instance.average_response_time,
            'fulfillment_rate': instance.fulfillment_rate,
        }
        return Response(performance_data)

class PurchaseOrderAcknowledgeView(generics.UpdateAPIView):
    queryset = PurchaseOrder.objects.all()
    serializer_class = PurchaseOrderSerializer

    def perform_update(self, serializer):
        instance = serializer.save(acknowledgment_date=timezone.now())
        
        # Calculate response time in seconds
        response_time_seconds = (instance.acknowledgment_date - instance.issue_date).total_seconds()
        
        # Assign the calculated response time to average_response_time
        instance.vendor.average_response_time = response_time_seconds

        # Save the vendor to update the performance metrics
        instance.vendor.save()

        return Response({'detail': 'Purchase Order acknowledged successfully.'}, status=status.HTTP_200_OK)
    
    # def get(self, request, *args, **kwargs):
    #     return Response({'detail': 'GET method not allowed. Use POST to acknowledge a purchase order.'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)
    
    def get(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        acknowledgment_data = {
            'acknowledgment_date': instance.acknowledgment_date,
            'response_time_seconds': (instance.acknowledgment_date - instance.issue_date).total_seconds(),
            'vendor_id': instance.vendor.id,
            
        }
        return Response(acknowledgment_data)